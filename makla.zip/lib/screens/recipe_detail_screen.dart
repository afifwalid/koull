import 'package:flutter/material.dart';

class RecipeDetailScreen extends StatelessWidget {
  final String recipeName;

  const RecipeDetailScreen({Key? key, required this.recipeName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Map<String, Map<String, String>> recipeDetails = {
      'كفتة مشوية': {
        'المكونات': 'لحم مفروم، بصل، توابل، زيت زيتون',
        'طريقة التحضير': 'امزج المكونات وشكل الكفتة ثم اشويها.',
        'طريقة الطهي': 'اشوي الكفتة على الجريل لمدة 10 دقائق.',
        'طريقة التقديم': 'قدّم الكفتة مع الأرز أو الخبز.',
      },
      // إضافة المزيد من الوصفات
    };

    final recipe = recipeDetails[recipeName];

    return Scaffold(
      appBar: AppBar(
        title: Text(recipeName),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/dall.png',
            fit: BoxFit.cover,
          ),
          recipe == null
              ? const Center(
                  child: Text(
                    'تفاصيل الوصفة غير متوفرة.',
                    style: TextStyle(color: Color(0xff3a0202)),
                  ),
                )
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'المكونات:',
                        style:
                            TextStyle(fontSize: 16, color: Color(0xff4e0909)),
                      ),
                      Text(recipe['المكونات']!,
                          style: const TextStyle(color: Color(0xff330202))),
                      const SizedBox(height: 20),
                      const Text(
                        'طريقة التحضير:',
                        style:
                            TextStyle(fontSize: 20, color: Color(0xff3d0202)),
                      ),
                      Text(recipe['طريقة التحضير']!,
                          style: const TextStyle(color: Color(0xff360404))),
                      const SizedBox(height: 20),
                      const Text(
                        'طريقة الطهي:',
                        style:
                            TextStyle(fontSize: 18, color: Color(0xff4e0606)),
                      ),
                      Text(recipe['طريقة الطهي']!,
                          style: const TextStyle(color: Color(0xff500707))),
                      const SizedBox(height: 10),
                      const Text(
                        'طريقة التقديم:',
                        style:
                            TextStyle(fontSize: 18, color: Color(0xff610909)),
                      ),
                      Text(recipe['طريقة التقديم']!,
                          style: const TextStyle(color: Color(0xff660b0b))),
                    ],
                  ),
                ),
        ],
      ),
    );
  }
}
