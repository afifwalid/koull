import 'package:flutter/material.dart';
import 'recipe_list_screen.dart'; // تأكد من تضمين ملف RecipeListScreen

class MealSelectionScreen extends StatefulWidget {
  const MealSelectionScreen({Key? key}) : super(key: key);

  @override
  MealSelectionScreenState createState() => MealSelectionScreenState();
}

class MealSelectionScreenState extends State<MealSelectionScreen> {
  String? selectedProtein = 'لحم'; // القيمة الافتراضية للبروتين
  String? selectedPeopleCount = '1'; // القيمة الافتراضية لعدد الأفراد

  final List<String> proteins = ['لحم', 'دجاج', 'سمك', 'بيض', 'لاشيء'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('اختيار الوجبة'),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/dall.png', // تأكد من وضع المسار الصحيح للصورة
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'اختر نوع البروتين:',
                  style: TextStyle(fontSize: 31, color: Color(0xff360707)),
                ),
                DropdownButton<String>(
                  value: selectedProtein,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedProtein = newValue;
                    });
                  },
                  items: proteins.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value,
                          style: const TextStyle(color: Color(0xffea6c6c))),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 30),
                const Text(
                  'عدد الأفراد:',
                  style: TextStyle(color: Color(0xffe86363)),
                ),
                TextField(
                  keyboardType: TextInputType.number,
                  onChanged: (String value) {
                    setState(() {
                      selectedPeopleCount = value;
                    });
                  },
                  decoration: const InputDecoration(
                    hintText: 'أدخل عدد الأفراد (من 1 إلى 4)',
                    border: OutlineInputBorder(),
                    hintStyle: TextStyle(color: Color(0xffffffff)),
                  ),
                ),
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: () {
                    if (selectedProtein != null &&
                        selectedPeopleCount != null) {
                      int peopleCount = int.tryParse(selectedPeopleCount!) ?? 1;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RecipeListScreen(
                            proteinType: selectedProtein!,
                            peopleCount: peopleCount,
                          ),
                        ),
                      );
                    }
                  },
                  child: const Text('عرض الوصفات'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
